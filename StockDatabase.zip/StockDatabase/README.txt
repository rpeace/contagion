Creator: John Caskey / JohnLeeCaskey@gmail.com

Contains 2000-2015 stock information for 1800 companies grouped by country, sector, and exchange.

WARNING: Currency may vary between exchanges
	
Exported using MySQL Wokbench 6.2.5
https://www.mysql.com/products/workbench/

Resources:
	-	http://www.stoxx.com/indices/index_information.html?symbol=SXW1E
	-	http://www.quotenet.com/stock-price/Antofagasta
	-	https://www.google.ca/finance?hl=en&gl=ca
	-	http://www.wikinvest.com/wiki/List_of_Stock_Exchanges
	-	https://countrycode.org/