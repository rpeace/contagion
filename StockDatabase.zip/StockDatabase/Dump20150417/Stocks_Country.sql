-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 192.168.0.103    Database: Stocks
-- ------------------------------------------------------
-- Server version	5.5.41-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Country`
--

DROP TABLE IF EXISTS `Country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Country` (
  `countryID` int(11) NOT NULL AUTO_INCREMENT,
  `regionID` int(11) NOT NULL,
  `countryCode` varchar(26) NOT NULL,
  `country` varchar(26) NOT NULL,
  PRIMARY KEY (`countryID`),
  KEY `regionID` (`regionID`),
  CONSTRAINT `Country_ibfk_1` FOREIGN KEY (`regionID`) REFERENCES `Region` (`regionID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Country`
--

LOCK TABLES `Country` WRITE;
/*!40000 ALTER TABLE `Country` DISABLE KEYS */;
INSERT INTO `Country` VALUES (1,2,'AT','Austria'),(2,3,'AU','Australia'),(3,2,'BE','Belgium'),(4,1,'CA','Canada'),(5,2,'CH','Switzerland'),(6,2,'CZ','Czech Republic'),(7,2,'DE','Germany'),(8,2,'DK','Denmark'),(9,2,'ES','Spain'),(10,2,'FI','Finland'),(11,2,'FR','France'),(12,2,'GB','United Kingdom'),(13,2,'GR','Greece'),(14,3,'HK','Hong Kong'),(15,2,'IE','Ireland'),(16,2,'IT','Italy'),(17,3,'JP','Japan'),(18,2,'LU','Luxembourg'),(19,2,'NL','Netherlands'),(20,2,'NO','Norway'),(21,3,'NZ','New Zealand'),(22,2,'PT','Portugal'),(23,2,'SE','Sweden'),(24,3,'SG','Singapore'),(25,1,'US','United States');
/*!40000 ALTER TABLE `Country` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-17  2:27:34
