-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 192.168.0.103    Database: Stocks
-- ------------------------------------------------------
-- Server version	5.5.41-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Exchange`
--

DROP TABLE IF EXISTS `Exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Exchange` (
  `exchangeID` int(11) NOT NULL AUTO_INCREMENT,
  `exchangeCode` varchar(26) NOT NULL,
  `exchange` varchar(26) NOT NULL,
  PRIMARY KEY (`exchangeID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Exchange`
--

LOCK TABLES `Exchange` WRITE;
/*!40000 ALTER TABLE `Exchange` DISABLE KEYS */;
INSERT INTO `Exchange` VALUES (1,'AMS','Amsterdam Stock Exchange'),(2,'ASX','Australian Securities Exch'),(3,'BIT','Borsa Italiana'),(4,'BME','Bolsas y Mercados Españole'),(5,'CPH','Copenhagen Stock Exchange'),(6,'EBR','Euronext - Brussels'),(7,'ELI','Euronext - Lisbon'),(8,'EPA','Euronext - Paris'),(9,'FRA','Frankfurt Stock Exchange'),(10,'HEL','OMX Nordic Exchange - Hels'),(11,'HKG','Hong Kong Stock Exchange'),(12,'LON','London Stock Exchange'),(13,'NASDAQ','National Association of Se'),(14,'NYSE','New York Stock Exchange'),(15,'NZE','New Zealand Exchange'),(16,'OTCMKTS','OTC Markets Group'),(17,'SGX','Singapore Exchange Limited'),(18,'STO','OMX Nordic Exchange - Stoc'),(19,'SWX','SWX Swiss Exchange'),(20,'TSE','Toronto Stock Exchange'),(21,'TYO','Tokyo Stock Exchange'),(22,'VIE','Vienna Stock Exchange'),(23,'VTX','SIX Swiss Exchange'),(24,'ETR','Exchange Electronic Tradin');
/*!40000 ALTER TABLE `Exchange` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-17  2:27:33
